/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkgravityflow"] = self["webpackChunkgravityflow"] || []).push([["common-inbox"],{

/***/ "./src/js/common/components/inbox.js":
/*!*******************************************!*\
  !*** ./src/js/common/components/inbox.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/**\n * Inbox\n *\n * Initializes the inbox component\n */\nvar el = {};\n\nvar init = function init(container) {\n  el.container = container;\n  console.info('Gravity Flow Common: Initialized inbox component.');\n};\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (init);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ncmF2aXR5Zmxvdy8uL3NyYy9qcy9jb21tb24vY29tcG9uZW50cy9pbmJveC5qcz9jMDA0Il0sIm5hbWVzIjpbImVsIiwiaW5pdCIsImNvbnRhaW5lciIsImNvbnNvbGUiLCJpbmZvIl0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLElBQU1BLEVBQUUsR0FBRyxFQUFYOztBQUVBLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUVDLFNBQUYsRUFBaUI7QUFDN0JGLElBQUUsQ0FBQ0UsU0FBSCxHQUFlQSxTQUFmO0FBRUFDLFNBQU8sQ0FBQ0MsSUFBUixDQUFjLG1EQUFkO0FBQ0EsQ0FKRDs7QUFNQSxpRUFBZUgsSUFBZiIsImZpbGUiOiIuL3NyYy9qcy9jb21tb24vY29tcG9uZW50cy9pbmJveC5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogSW5ib3hcbiAqXG4gKiBJbml0aWFsaXplcyB0aGUgaW5ib3ggY29tcG9uZW50XG4gKi9cblxuY29uc3QgZWwgPSB7fTtcblxuY29uc3QgaW5pdCA9ICggY29udGFpbmVyICkgPT4ge1xuXHRlbC5jb250YWluZXIgPSBjb250YWluZXI7XG5cblx0Y29uc29sZS5pbmZvKCAnR3Jhdml0eSBGbG93IENvbW1vbjogSW5pdGlhbGl6ZWQgaW5ib3ggY29tcG9uZW50LicgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGluaXQ7XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/common/components/inbox.js\n");

/***/ })

}]);